﻿using atajados;
using atajados.Data;
using atajados.PageModels;
using atajados.Pages;
using atajados.Services;
using CommunityToolkit.Maui;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Maui;
using Microsoft.Maui.Hosting;

namespace atajados
{
    public static class MauiProgram
    {
        public static MauiApp CreateMauiApp()
        {
            var builder = MauiApp.CreateBuilder();

            builder
                .UseMauiApp<App>()
                .UseMauiCommunityToolkit()
                .ConfigureFonts(fonts =>
                {
                    fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                });

            // DbContext para SQLite
            builder.Services.AddDbContextFactory<AppDbContext>(options =>
                options.UseSqlite($"Filename={FileSystem.AppDataDirectory}/atajados.db")
            );

            // Servicios
            builder.Services.AddSingleton<DatabaseService>();
            builder.Services.AddSingleton<ExcelService>();

            // Shell
            builder.Services.AddSingleton<AppShell>();

            // Páginas y ViewModels
            builder.Services.AddTransient<ItemsPage>();
            builder.Services.AddTransient<ItemsViewModel>();
            builder.Services.AddTransient<MainPage>();
            builder.Services.AddTransient<MainPageModel>();
            builder.Services.AddTransient<ProjectListPage>();
            builder.Services.AddTransient<ProjectListPageModel>();
            builder.Services.AddTransient<ProjectDetailPage>();
            builder.Services.AddTransient<ProjectDetailPageModel>();
            builder.Services.AddTransient<TaskDetailPage>();
            builder.Services.AddTransient<TaskDetailPageModel>();
            builder.Services.AddTransient<ManageMetaPage>();
            builder.Services.AddTransient<ManageMetaPageModel>();


            return builder.Build();
        }
    }
}
