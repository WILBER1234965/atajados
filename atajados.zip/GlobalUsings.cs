global using atajados.Data;
global using atajados.PageModels;
global using atajados.Pages;
global using atajados.Services;
global using atajados.Utilities;
global using Fonts;
