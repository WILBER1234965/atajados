using System;

namespace atajados.Models
{
    public class IconData
    {
        public string? Icon { get; set; }
        public string? Description { get; set; }
    }
}
