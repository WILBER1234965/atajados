﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace atajados.Models
{
    public class Item
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Numero { get; set; }
        [Required]
        public string Descripcion { get; set; }
        public string Unidad { get; set; }
        [Required]
        public decimal Cantidad { get; set; }
        [Required]
        public decimal PrecioUnitario { get; set; }
        [NotMapped]
        public decimal Total => Cantidad * PrecioUnitario;
        public bool UsarEnSeguimiento { get; set; }
    }
}
