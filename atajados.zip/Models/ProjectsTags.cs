namespace atajados.Models
{
    public class ProjectsTags
    {
        public int ID { get; set; }
        public int ProjectID { get; set; }
        public int TagID { get; set; }
    }
}