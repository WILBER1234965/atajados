﻿using System.ComponentModel.DataAnnotations;

namespace atajados.Models
{
    public class Atajado
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Comunidad { get; set; }
        [Required]
        public string NumeroAtajado { get; set; }
        [Required]
        public string Nombre { get; set; }
        public string CI { get; set; }
        public decimal Este { get; set; }
        public decimal Norte { get; set; }
    }
}
