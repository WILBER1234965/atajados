﻿// AppShell.xaml.cs
using Microsoft.Maui.Controls;

namespace atajados
{
    public partial class AppShell : Shell
    {
        public AppShell()
        {
            InitializeComponent();
        }
    }
}
