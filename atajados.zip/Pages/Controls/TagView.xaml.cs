namespace atajados.Pages.Controls
{
    public partial class TagView
    {
        public TagView()
        {
            InitializeComponent();
        }
    }
}