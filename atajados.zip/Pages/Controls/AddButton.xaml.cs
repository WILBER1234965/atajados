namespace atajados.Pages.Controls
{
    public partial class AddButton
    {
        public AddButton()
        {
            InitializeComponent();
        }
    }
}