namespace atajados.Pages.Controls
{
    public partial class CategoryChart
    {
        public CategoryChart()
        {
            InitializeComponent();
        }
    }
}