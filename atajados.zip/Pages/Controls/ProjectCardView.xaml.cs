namespace atajados.Pages.Controls
{
    public partial class ProjectCardView
    {
        public ProjectCardView()
        {
            InitializeComponent();
        }
    }
}