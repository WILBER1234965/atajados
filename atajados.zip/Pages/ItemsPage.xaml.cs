﻿using Microsoft.Maui.Controls;
using atajados.PageModels;

namespace atajados.Pages
{
    public partial class ItemsPage : ContentPage
    {
        public ItemsPage(ItemsViewModel vm)
        {
            InitializeComponent();
            BindingContext = vm;
        }
    }
}
