﻿using Microsoft.EntityFrameworkCore;
using atajados.Models;

namespace atajados.Data
{
    public class AppDbContext : DbContext
    {
        public DbSet<Item> Items { get; set; }
        public DbSet<Atajado> Atajados { get; set; }
        public DbSet<Seguimiento> Seguimientos { get; set; }

        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }
    }
}
